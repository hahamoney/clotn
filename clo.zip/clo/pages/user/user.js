const app = getApp()

Page({
  data: {
    username: '',
    avatarUrl:'/image/icon_7.png',
    show:false
  },

  error(){
    wx.showToast({
      title: '暂未开放',
      icon: 'none'
    })
  },

  onLoad: function () {
    var avatarUrl = wx.getStorageSync('avatarUrl');
    var username = wx.getStorageSync('username');
    this.setData({
      avatarUrl:avatarUrl,
      username: username,
    })
  },

  bindGetUserInfo(e){

    var _this = this;
      var userInfo = e.detail.userInfo;
      _this.setData({
        show:false,
      })
        wx.login({
          success(res) {
            var code = res.code;
            wx.getUserInfo({
              success(res){
                  console.log(res);

                wx.request({
                  url: app.data.api + 'sign_in',
                  method: 'post',
                  dataType: 'Json',
                  data: { code: code, userInfo: userInfo, type: 2, iv: res.iv, encryptedData: res.encryptedData },
                  success(res) {
                    var data = JSON.parse(res.data);
                    wx.setStorageSync('user_id', data.id);
                    wx.setStorageSync('avatarUrl', data.avatarUrl);
                    wx.setStorageSync('username', data.name);
                    _this.setData({
                      avatarUrl: data.avatarUrl,
                      username: data.name,

                    })
                  }
                })
              }
            })
          }
        })
      },
  onClose(){
    this.setData({
      show:false
    })
  }, login(){
    this.setData({
        show:true,
    });
  }
})